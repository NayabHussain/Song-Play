package com.example.demogradle;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SongPlayApplication {

	public static void main(String[] args) {
		SpringApplication.run(SongPlayApplication.class, args);

		SongPlayServiceImpl songPlayServiceImpl = new SongPlayServiceImpl();
		songPlayServiceImpl.playSong();
	}
}
