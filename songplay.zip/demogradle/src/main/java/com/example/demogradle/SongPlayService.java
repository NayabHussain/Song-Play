package com.example.demogradle;

public interface SongPlayService {

	public void playSong();
}
