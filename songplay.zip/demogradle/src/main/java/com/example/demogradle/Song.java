package com.example.demogradle;

public class Song {

	private String songName;
	private Integer songNumber;
	private Integer durationInseconds;
	
	

	public String getSongName() {
		return songName;
	}

	public void setSongName(String songName) {
		this.songName = songName;
	}

	public Integer getSongNumber() {
		return songNumber;
	}

	public void setSongNumber(Integer songNumber) {
		this.songNumber = songNumber;
	}

	public Integer getDurationInseconds() {
		return durationInseconds;
	}

	public void setDurationInseconds(Integer durationInseconds) {
		this.durationInseconds = durationInseconds;
	}

	

	

}
